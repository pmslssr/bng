package com.bmc.exception;


public class MetroException extends Exception {
	public MetroException(String errMsg) {
		super(errMsg);
}
}
