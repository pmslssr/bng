package com.bmc.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bmc.bean.MetroBean;
import com.bmc.exception.MetroException;
import com.bmc.service.IMetroService;
import com.bmc.service.MetroServiceImpl;


/**
 * Servlet implementation class RegisterController
 */
@WebServlet("*.obj")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(false);		
		MetroBean bean = new MetroBean();
		IMetroService service = new MetroServiceImpl();
		String path = request.getServletPath().trim();
		String target="";
	    switch(path){

		case "/home.obj":
			target = "home.jsp";
			break;
		case "/register.obj":
			target = "register.jsp";
			break;
		case "/add.obj":

			String middle=request.getParameter("middle");
			String name="";
			if(middle==null)
			{
				name=request.getParameter("first")+" "+request.getParameter("last");
			}
			else
			{
				name=request.getParameter("first")+" "+request.getParameter("middle")
						+" "+request.getParameter("last");
			}
			String businessname =request.getParameter("businessname");
			String email=request.getParameter("email");
			String phoneno=request.getParameter("mobileno");
			long mno = Long.parseLong(phoneno);
			bean.setOwnerName(name);
			bean.setBusinessName(businessname);
			bean.setEmail(email);
			bean.setMobileNo(mno);
			
			
	    	System.out.println("Inside add obj");
	    	try {
				int id = service.addDetails(bean);
				if(id!=0)
				{
					Random rd=new Random();
					int actcode=rd.nextInt(2000);
					session.setAttribute("email",bean.getEmail());
					session.setAttribute("code", actcode);
					//out.println("code" +actcode);
			        target="success.jsp";
				}
				else
				{
					target="errorpage.jsp";
				}
			} catch (MetroException e) {

				System.out.println("Exception"+e.getMessage());
				target="errorpage.jsp";
			}
			break;
		case "/activate.obj":
			target = "activate.jsp";
			break;
		case "/activated.obj":

			System.out.println("inside active");
	    	String emailform = request.getParameter("acemail");
	    	System.out.println(emailform);
	    	String emailsession = (String)session.getAttribute("email");
	    	System.out.println(emailsession);
	    	int codeform = Integer.parseInt(request.getParameter("code"));
	    	System.out.println(codeform);
	    	int codesession=(Integer)(session.getAttribute("code"));
	    	System.out.println(codesession);
	    	if(emailform.equals(emailsession)&&(codeform==codesession))
	    	{
	    		try {
					boolean flag = service.updateReg(emailsession);
					System.out.println(flag);
					if(flag)
					{
						target="activated.jsp";
					}
				} catch (MetroException e) {

				    target="error.jsp";
				}
	    	}
	    	break;
	    	default:
	    		target = "home.jsp";
			break;
		
	    }
	    RequestDispatcher dispatcher = request.getRequestDispatcher(target);
	    dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doGet(request, response);	}

}
