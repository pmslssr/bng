package com.bmc.bean;

public class MetroBean {
private  int firmId ;
private String  ownerName ;
private String businessName ;
private String email ;
private Long mobileNo ;
public MetroBean() {
	super();
	// TODO Auto-generated constructor stub
}
public MetroBean(int firmId, String ownerName, String businessName,
		String email, Long mobileNo) {
	super();
	this.firmId = firmId;
	this.ownerName = ownerName;
	this.businessName = businessName;
	this.email = email;
	this.mobileNo = mobileNo;
}
public int getFirmId() {
	return firmId;
}
public void setFirmId(int firmId) {
	this.firmId = firmId;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public String getBusinessName() {
	return businessName;
}
public void setBusinessName(String businessName) {
	this.businessName = businessName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(Long mobileNo) {
	this.mobileNo = mobileNo;
}
@Override
public String toString() {
	return "MetroBean [firmId=" + firmId + ", ownerName=" + ownerName
			+ ", businessName=" + businessName + ", email=" + email
			+ ", mobileNo=" + mobileNo + "]";
}

}
