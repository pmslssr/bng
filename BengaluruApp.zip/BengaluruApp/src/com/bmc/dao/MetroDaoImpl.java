package com.bmc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bmc.bean.MetroBean;
import com.bmc.exception.MetroException;
import com.bmc.util.DBConnection;


public class MetroDaoImpl implements IMetroDao {


	@Override
	public int addDetails(MetroBean bean) throws MetroException {
       int id=0;
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QUERY);
		    pstmt.setString(1,bean.getOwnerName());
		    pstmt.setString(2, bean.getBusinessName());
		    pstmt.setString(3, bean.getEmail());
		    pstmt.setLong(4, bean.getMobileNo());
		    
		    int count = pstmt.executeUpdate();
		    if(count<=0)
		    {
		    	System.out.println("INSERTION FAIL");
		    }
		    else
		    {
		    	System.out.println("INSERTION IS DONE");
		    	id=count;
		    }
		
		} catch (SQLException e) {
   
			System.out.println(e.getMessage());
		}
		
		return (id);
	}
	
	@Override
	public boolean updateReg(String email) throws MetroException {
        boolean flag=false;
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_QUERY);
		    pstmt.setString(1,email);
		    int count = pstmt.executeUpdate();
		    if(count>0)
		    {
		    	flag=true;
		    }
		} catch (SQLException e) {

		     System.out.println(e.getMessage());
		}
		return flag;
	}
	
}
