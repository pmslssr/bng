package com.bmc.dao;

public class QueryMapper {

	public static final String INSERT_QUERY="insert into FIRMS_MASTER(firm_id ,owner_name ,business_name ,email,mobile_no,isactive) values(seq_firm_master.nextval,?,?,?,?,'N')";
    public static final String UPDATE_QUERY="update FIRMS_MASTER set isactive='Y' where email=?";

}
