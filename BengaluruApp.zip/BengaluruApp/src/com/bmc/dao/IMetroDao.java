package com.bmc.dao;

import com.bmc.bean.MetroBean;
import com.bmc.exception.MetroException;

public interface IMetroDao {
	public int addDetails(MetroBean bean) throws MetroException;
	 public boolean updateReg(String email) throws MetroException;
	

}
