package com.bmc.service;

import com.bmc.bean.MetroBean;
import com.bmc.dao.IMetroDao;
import com.bmc.dao.MetroDaoImpl;
import com.bmc.exception.MetroException;

public class MetroServiceImpl implements IMetroService {

	private IMetroDao dao = new MetroDaoImpl();
	int id=0;
	@Override
	public int addDetails(MetroBean bean) throws MetroException {
		
		id=dao.addDetails(bean);
		return (id);
	}
	@Override
	 public boolean updateReg(String email) throws MetroException{
		// TODO Auto-generated method stub
		return dao.updateReg(email);
	}

}
