package com.bmc.service;

import com.bmc.bean.MetroBean;
import com.bmc.exception.MetroException;


public interface IMetroService {

 public	int addDetails(MetroBean bean) throws MetroException;
 public boolean updateReg(String email) throws MetroException;
}
