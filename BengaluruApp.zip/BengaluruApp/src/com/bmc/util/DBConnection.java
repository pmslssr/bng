package com.bmc.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.bmc.exception.MetroException;



public class DBConnection {

	static Connection connection;

	public static Connection getConnection() throws MetroException {
	
			try {
				InitialContext context = new InitialContext();
				DataSource source = (DataSource) context.lookup("java:/jdbc/MYDS");
				connection = source.getConnection();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				throw new MetroException("Naming Exception found");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new MetroException("SQL EXP found");
			}
	
		return connection;
	}
	
}
